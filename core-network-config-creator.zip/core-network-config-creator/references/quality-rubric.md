# 质量评判体系 (Quality Rubric)

三层 fail-fast：**第 1–2 层任一 FAIL 即返工，不进入打分**；全过后按第 3 层评分卡定级。
评判对象：LLD JSON / Excel、转换代码、动网命令脚本。

## 第 1 层 确定性自动校验 (Deterministic Checks)

执行：`python scripts/validate_outputs.py --lld lld.json --cmds commands.txt --code transform.py --existing existing.cfg`（参数可单独使用）

| 检查项 | 判定 |
|---|---|
| LLD JSON：schema 标识、meta 必填字段、日期格式、revision 整数、配置节至少一项非空 | FAIL |
| LLD 值占位符残留（TODO/FIXME/XXX/`<...>`/`{var}`） | WARN（草稿期允许，未清理不可交付） |
| 命令脚本：完全重复命令行 | FAIL |
| 命令脚本：先删后建同对象（冲突对） | WARN → 转人工确认 |
| 命令脚本：高危命令关键词（RMV/DEL/RESET/RST/DEACT/FORCE/删除/复位/去激活/清除/强制…） | WARN → 列入人工审核关卡 |
| 转换代码语法编译 | FAIL |

依据：网络变更 pre-change validation / network-as-code 实践——变更前自动校验作为放行证据（ManageEngine、Cisco Network as Code、TechTarget）。

## 第 2 层 执行式评估 (Execution-based, 二值判定)

由 `validate_outputs.py --code ... --existing ...` 自动执行（需代码采用可选 CLI 约定，见 codegen-guide.md；未采用时评判者手动运行两次并逐字节比对，判定标准不变）：

1. **实际运行成功**：转换代码在用户提供的存量配置样例上运行，退出码 0 且输出非空。FAIL 条件：异常退出、输出为空。
2. **断言检查**：输出命令条数 > 0；关键参数存在性（按网元类型，如 AMF 场景命令中应含 PLMN/GUAMI 相关项——具体断言清单在评判时按 LLD 的 `command_list` 核对）。
3. **幂等性测试**：连续运行两次，输出文件逐字节一致。FAIL 条件：任何差异（常见根因：时间戳、随机数、未排序容器遍历）。

依据：LLM 代码生成评估共识——执行式评估（编译通过/单测通过/pass@k）是最直接的功能性评估（arXiv:2408.16498 综述、XCODEEVAL）；且测试数据质量决定可靠性，因此必须用**真实存量配置**而非构造数据。

## 第 3 层 LLM 评分卡 (LLM-as-a-Judge)

仅评机器不可判定的维度。纪律（来自 LLM-as-a-Judge 实践，Comet/Agenta/Monte Carlo/arXiv）：

- **锚定量表**：每维度 1–5 分，每个分值有具体锚定描述；禁止模糊 1–10 分。
- **一次评一个维度**；每个判定**必须引用具体证据**（命令行号 / LLD 字段 / 运行输出），无证据的判定无效。
- **冗长 ≠ 高分**：以知识库与 LLD 为准，不以篇幅论。
- **A/B 迭代用成对比较 (pairwise)**：同一份存量配置下对比新旧输出，交换呈现顺序评两次，结论一致才采纳（消除位置偏差）。

### 维度与锚定示例

| 对象 | 维度 (权重) | 1 分锚定 | 3 分锚定 | 5 分锚定 |
|---|---|---|---|---|
| LLD | 参数完整性 (30%) | 多个必填参数空缺或"待确认" | 个别次要参数缺失 | 必填全齐且备注清晰 |
| LLD | 与场景匹配 (30%) | 配置域与场景明显不符 | 基本匹配有冗余/遗漏 | 恰好覆盖场景所需配置域 |
| LLD | 数据规划合理性 (25%) | IP/号码资源与存量冲突 | 无冲突但未留扩展 | 无冲突、预留合理且有依据 |
| LLD | 可读性 (15%) | 分组混乱无法评审 | 基本可读 | 分组/命名规范，可直接评审 |
| 代码 | 结构清晰 (40%) | 无分层、逻辑纠缠 | 有分层但耦合 | 五层清晰、职责单一 |
| 代码 | 可维护性 (30%) | 参数硬编码 | 部分硬编码 | 参数全部来自 LLD JSON |
| 代码 | 日志与变更摘要质量 (30%) | 无摘要 | 有摘要缺高危清单 | 统计+高危+待确认齐全 |
| 动网配置 | 变更最小性 (40%) | 未做 delta 全量下发 | 有 delta 但含冗余 | 仅必要变更，无重复 |
| 动网配置 | 命令组织与分组 (30%) | 无分组混杂 | 有分组不完整 | 分组注释完整有序 |
| 动网配置 | 回滚说明完整性 (30%) | 无回滚提示 | 有提示不完整 | 每项 DEL/MOD 有反操作提示 |

总分 = 各维度得分按权重加权（按对象分别出分；交付判定取三对象最低者）。

## 综合结论与人工关卡

| 条件 | 结论 |
|---|---|
| 第 1–2 层全过 且 第 3 层总分 ≥ 4.0 且无高危命令（或高危已确认） | **可交付** |
| 第 1–2 层全过 且 3.0 ≤ 总分 < 4.0 | **需小改后复评** |
| 第 1 或 2 层任一 FAIL，或总分 < 3.0 | **返工**（回 Step 6） |
| 存在未确认的高危命令 | 无论评分**一律不可交付**，先人工确认 |

命令脚本头部必须保留回滚提示区（rollback readiness）。

## 评判报告模板

```markdown
# 质量评判报告 — <网元名> <场景>
日期 / 评判轮次 (对应 meta.revision):

## 第 1 层 自动校验
- [PASS/FAIL] 每项检查结果（引用 validate_outputs.py 输出行）
## 第 2 层 执行式评估
- 运行退出码 / 输出文件数 / 幂等性比对结果
## 第 3 层 评分卡
| 对象 | 维度 | 得分 | 证据 |
（每行证据引用具体命令行号/LLD 字段/输出内容）
## 结论
可交付 / 需小改后复评 / 返工
## 问题清单与修改建议
1. ... → 建议 ...
## 人工确认项（高危命令）
- [ ] 命令 N: ...（确认人/时间）
```

## 方法来源 (References)

- 执行式评估：arXiv:2408.16498《A Survey on Evaluating LLMs in Code Generation》；XCODEEVAL (ACL 2024)
- LLM-as-a-Judge：Comet《LLM-as-a-Judge: The Ultimate Guide》；Agenta LLM Evaluation Best Practices；Monte Carlo《LLM-As-Judge: 7 Best Practices》；锚定量表/位置偏差/成对比较结论均出自上述实践
- Pre-change 校验与回滚就绪：ManageEngine Network Validation；Cisco Network as Code — Validation (pre-change validation & delta analysis)；TechTarget《Automate Network Validation for Smoother Changes》
