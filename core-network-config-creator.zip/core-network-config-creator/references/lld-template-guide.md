# LLD 模板指南 (LLD Template Guide)

用途：Step 1 模板决策、Step 2 编写 LLD JSON、Step 3 生成 Excel 前的规范与示例。

LLD JSON 是 LLD 的**结构化载体**：供 `validate_outputs.py` 校验、状态恢复（中断续作）、Step 4 参数来源使用；Excel 交付物由运行时按意图编写的代码按本 JSON 的模板结构生成。

## 模板优先级（核心纪律）

**LLD 的表结构（sheet 与列）与命令语法同等约束——不得凭空编造。** 决策顺序：

| 优先级 | 来源 | template.source 填写 |
|---|---|---|
| 1 | 知识库模板（检索 `{网元类型} {版本} LLD 模板/低阶设计模板`） | kb 出处，如 `kb: VendorX AMF V5.1.0 LLD模板` |
| 2 | 用户提供的公司/项目模板（xlsx / docx / 文字描述） | 文件名，如 `用户提供: XX移动5GC_LLD模板V2.xlsx` |
| 3 | 内置兜底骨架（本文附录，8 sheet 通用格式） | —（不使用 template 节） |

走到第 3 级时必须告知用户："当前使用通用兜底格式，建议将贵司模板入库。"

## schema v1.1（模板模式）

```jsonc
{
  "schema": "core-network-lld/1.1",
  "meta": { /* 同附录 v1.0，字段不变 */ },
  "template": {
    "source": "kb: VendorX AMF V5.1.0 LLD模板",   // 必填非空：模板出处（可追溯）
    "sheets": [
      { "title": "N2接口",
        "columns": ["序号","本端模块","本端IP","SCTP端口","对端gNB","对端IP","备注"],
        "data_ref": "n2" }
    ]
  },
  "data": {
    "n2": [ ["1","MOD-01","10.1.1.10","38412","gNB-A","10.2.1.5",""] ]
  }
}
```

### 校验规则（由 validate_outputs.py 执行）

| 规则 | 判定 |
|---|---|
| template.source 非空 | FAIL |
| template.sheets 非空数组；每表 title / columns（非空字符串数组）/ data_ref 非空 | FAIL |
| 每个 data_ref 必须在 data 中存在 | FAIL |
| 每行长度必须等于该表列数 | FAIL |
| 全部数据表为空 | FAIL |
| data 中未被任何 sheet 引用的键 | WARN（孤儿数据不渲染） |
| 值中残留占位符（TODO/FIXME/XXX/`<…>`/`{var}`） | WARN（草稿期允许，交付前必须清理，未清理不可交付） |
| meta 必填字段 / 日期格式 / revision 整数 | FAIL |

### 从用户模板文件提取表结构

- **xlsx**：openpyxl `load_workbook(read_only=True)` 遍历 `wb.sheetnames`，取每表**首行**为列定义；空表跳过；合并单元格/双层表头须人工整理。
- **docx**：读取文档中的表格（每表首行为列），连同表名/说明一并记录。
- **文字或截图描述**：按用户口述整理列清单。
- 任何来源的提取结果都必须先向用户展示"sheet + 列"清单确认，再写入 `template` 节。

## 填充示例（v1.1，节选）

```json
{
  "schema": "core-network-lld/1.1",
  "meta": {
    "project": "XX省5GC二期", "scenario": "割接改造", "ne_type": "AMF",
    "ne_name": "AMF-01", "vendor": "VendorX", "version": "V5.1.0",
    "author": "zcode", "date": "2026-08-27", "revision": 1
  },
  "template": {
    "source": "示例结构仅演示格式（实际以知识库检索为准）",
    "sheets": [
      { "title": "全局参数", "columns": ["参数名", "取值", "备注"], "data_ref": "global" },
      { "title": "N2接口", "columns": ["序号", "本端模块", "本端IP", "SCTP端口", "对端gNB", "对端IP", "备注"], "data_ref": "n2" },
      { "title": "存量差异", "columns": ["条目", "存量", "目标", "动作", "备注"], "data_ref": "delta" }
    ]
  },
  "data": {
    "global": [["PLMN", "460/00", ""], ["GUAMI", "Region=1,Set=1,Pointer=0", "新增"]],
    "n2": [["1", "MOD-01", "10.1.1.10", "38412", "gNB-A", "10.2.1.5", ""]],
    "delta": [["TAC 列表", "46001", "46001,46002", "MOD", ""]]
  }
}
```

注意：示例的表结构本身只是格式演示——**实际表结构必须来自模板决策的第 1/2 级来源**。

## 附录：兜底默认模板（v1.0 格式）

当模板决策走到第 3 级时使用。不写 `template`/`data` 节，改用下列配置节，Excel 产出按固定 8-sheet 骨架组织（概述/网元信息/全局参数/接口配置/业务特性参数/数据规划/命令清单/存量差异）：

```jsonc
{
  "schema": "core-network-lld/1.0",     // 或 "core-network-lld/1.1" 且无 template 节
  "meta": { /* 同上 */ },
  "global_params":  [ { "group": "移动性标识", "name": "AMF Region ID", "value": "1", "remark": "" } ],
  "interfaces":     [ { "name": "N2", "type": "SCTP", "local_end": "10.1.1.10:38412", "remote_end": "gNB-池A", "remark": "" } ],
  "service_params": [ { "group": "寻呼", "name": "寻呼定时器", "value": "8", "remark": "" } ],
  "data_plan":      [ { "group": "切片", "name": "S-NSSAI", "value": "010203", "remark": "eMBB" } ],
  "command_list":   [ { "seq": 1, "intent": "配置目的", "command": "命令（来自知识库）", "source": "kb: 出处", "remark": "" } ],
  "delta_notes":    [ { "item": "条目", "existing": "存量值", "target": "目标值", "action": "ADD|MOD|DEL", "remark": "" } ]
}
```

字段规则：meta 与占位符纪律同 v1.1；`command_list.source` 必填（命令追溯）；割接改造场景必填 `delta_notes`；`DEL` 动作的备注须写明人工确认人。
