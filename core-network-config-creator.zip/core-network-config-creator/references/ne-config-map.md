# 核心网网元配置域地图 (NE Config Domain Map)

用途：Step 0 确认本次涉及的配置域、Step 2 拟定分批问题清单的**路由级骨架**。
注意：具体参数名、取值范围与命令模板**以知识库运行时检索结果为准**，本文件不提供具体命令。

术语格式：中文名 (英文全称, 缩写)。

## 场景 → 配置域映射 (Scenario → Config Domains)

| 场景 | 涉及配置域 | delta 特征 |
|---|---|---|
| 新建局点 (greenfield) | 该网元全部配置域 | 全量 ADD，无存量 |
| 扩容 (capacity expansion) | 容量参数、资源池（IP 池/会话数/板卡）、接口扩容 | 以 ADD/MOD 为主 |
| 割接改造 (migration/restructuring) | 存量解析 + 变更域 | ADD/MOD/DEL 混合，高危命令集中 |
| 切片开通 (network slicing) | 切片标识 (S-NSSAI)、切片资源与路由 | AMF/SMF/UPF/NSSF 联动 |
| 接口对接 (new interconnection) | 对应接口域 + 对端数据 | 以 ADD 为主 |
| 参数整改 (parameter audit/tuning) | 指定参数域 | 以 MOD 为主 |

## 5GC 网元 (5G Core NFs)

### AMF 接入与移动性管理功能 (Access and Mobility Management Function)
- 全局：网元标识、容量、AMF Set 冗余
- 移动性标识：GUAMI（MCC/MNC + AMF Region ID / AMF Set ID / AMF Pointer）、PLMN 列表、TAC 列表
- 接口：N2 (SCTP，对 gNB)、N11（对 SMF）、N8（对 UDM）、N12（对 AUSF）、N20（对 SMSF）、NRF 注册 (Nnf)
- NAS 参数：注册/寻呼参数、寻呼策略信道
- 切片：支持的 S-NSSAI 列表、切片与 TAC 关联
- 信息采集重点：gNB 对接数据（IP/SCTP 端口）、PLMN/TAC 规划、切片需求

### SMF 会话管理功能 (Session Management Function)
- 全局：网元标识、容量
- PDU 会话：DNN 配置、会话类型 (IPv4/IPv6/IPv4v6)、SSC mode、默认 QoS (5QI/ARP)
- UE IP 池：按 DNN + S-NSSAI 规划（必查与存量冲突）
- 接口：N4 (PFCP，对 UPF)、N11（对 AMF）、N10（对 UDM）、N7（对 PCF）、DNS/DHCP
- 切片：S-NSSAI 与 DNN 关联
- 信息采集重点：DNN 清单、IP 池现状与增量、对接 UPF/PCF/UDM 数据

### UPF 用户面功能 (User Plane Function)
- 承载连接：端口/VLAN/IP 规划（必查冲突）
- 接口：N3 (GTP-U，对 gNB)、N4 (PFCP，对 SMF)、N6（对 DN）、N9（对其他 UPF）
- 转发：路由策略、QoS 执行（会话 AMBR/GBR）、上报（URR）
- 分流：上行分类器 (UL CL)、IPv6 Multi-homing、LADN、DNAI
- 信息采集重点：端口资源、N6 路由与 DNS、分流/本地出局需求

### NRF 网络仓储功能 (Network Repository Function)
- NF 注册与发现参数、维护的 NF Profile、OAuth2 授权配置
- 信息采集重点：全网 NF 清单、SBIF 安全策略

### 其他 NF（骨架）
- PCF 策略控制功能 (Policy Control Function)：PCC 规则、QoS 策略、计费策略；接口 N7 (对 SMF)、Rx (对 AF)
- UDM 统一数据管理 (Unified Data Management)：签约数据、鉴权向量生成；N8/N10
- UDR 统一数据仓储 (Unified Data Repository)：数据存储与 Ud 接口
- AUSF 鉴权服务功能 (Authentication Server Function)：5G-AKA / EAP-AKA'；N12/N13
- NSSF 网络切片选择功能 (Network Slice Selection Function)：切片选择、Allowed NSSAI；N22
- NEF 网络开放功能 (Network Exposure Function)：能力开放、外部 AF 对接
- BSF 绑定支持功能 (Binding Support Function)：PDU 会话与 PCF 绑定
- CHF 计费功能 (Charging Function)：计费话单与配额
- SMSF 短消息功能 (SMS Function)：NAS 短信

## EPC 网元 (4G Evolved Packet Core)

### MME 移动性管理实体 (Mobility Management Entity)
- 全局：GUMMEI（MCC/MNC + MMEGI/MMEC）、MME Pool、容量
- 跟踪区：TAC 列表 / TAI 规划
- 接口：S1-MME (SCTP，对 eNB)、S11 (GTP-C，对 SGW)、S6a (Diameter，对 HSS)、S10（MME 间）、S3（对 SGSN）
- NAS：附着/寻呼/TAU 参数
- 承载：默认承载与专用承载 QCI/ARP
- 信息采集重点：eNB 对接数据、Pool 划分、与 5G 互操作 (N26) 需求

### SGW 服务网关 (Serving Gateway)
- 接口：S1-U (GTP-U，对 eNB)、S5/S8 (GTP-C/GTP-U，对 PGW)、S11（对 MME）
- 转发：GTP-U 隧道、端口/IP 规划
- 信息采集重点：eNB/PGW 对接数据、隧道资源

### PGW 分组数据网关 (PDN Gateway)
- 接口：S5/S8、SGi（对 DN）、Gx (Diameter，对 PCRF)
- APN：APN 列表、UE IP 池（按 APN 规划，必查冲突）、DNS、DHCP
- QoS：默认/专用承载、APN-AMBR
- 信息采集重点：APN 清单、IP 池现状、计费特征

### HSS 归属用户服务器 (Home Subscriber Server)
- 用户数据模型、IMSI/MSISDN 号段、鉴权 (AuC)
- 接口：S6a（对 MME）、Cx (Diameter，对 CSCF)、Sh（对 AS）
- 信息采集重点：号段规划、与 IMS/EPC 的路由关系

### PCRF 策略与计费规则功能 (Policy and Charging Rules Function)
- PCC 规则 (Gx/Gx')、业务检测、QoS/计费策略；Rx (对 AF)

## IMS 网元 (IP Multimedia Subsystem)

### P-CSCF 代理呼叫会话控制功能 (Proxy CSCF)
- 接入侧 SIP 参数、与 S-CSCF/I-CSCF 的对接、IPsec 安全、QoS 触发 (Rx→PCRF)
- 信息采集重点：接入网段、SIP 监听端口/传输 (UDP/TCP/TLS)

### I-CSCF 询问 CSCF (Interrogating CSCF)
- HSS 查询 (Cx)、S-CSCF 选择策略、域名/拓扑隐藏 (THIG)

### S-CSCF 服务 CSCF (Serving CSCF)
- 注册与会话控制、HSS 对接 (Cx/Dx)、AS 触发 (ISC 接口、iFC 初始过滤准则)、ENUM/DNS
- 信息采集重点：用户号段、iFC 与 AS 对接、注册定时器

### IMS-HSS 与 AS 应用服务器 (Application Server)
- IMS-HSS：Cx/Sh、用户签约 (IMPU/IMPI)
- AS：SIP 对接 (ISC)、业务触发数据

## 分批提问顺序建议 (Question Batching Order)

全局参数 → 接口配置 → 业务/特性参数 → 数据规划。每批 3–5 问；数据规划批必须携带存量冲突检查结果一并呈现。
