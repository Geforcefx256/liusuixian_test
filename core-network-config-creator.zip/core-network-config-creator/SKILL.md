---
name: core-network-config-creator
description: 核心网网元配置生成器：根据场景、网元类型、网元版本，经知识库检索与对话式设计生成低阶设计 LLD（Excel 格式）与动网配置命令脚本，并可依据存量配置计算变更 delta。Generate LLD (Excel) and cutover/change configuration scripts for core network elements (5GC AMF/SMF/UPF/NRF/PCF/UDM/AUSF/NSSF, EPC MME/SGW/PGW/HSS/PCRF, IMS CSCF/HSS/AS). Use whenever 用户要求做网元配置设计、生成 LLD 或低阶设计、从存量配置生成动网/割接配置脚本、cutover script generation、NE configuration design，或给出"场景+网元类型+版本"要求产出配置。
---

# 核心网网元配置生成器 (Core Network NE Config Creator)

输入：**场景 + 网元类型 + 网元版本**（+ 存量配置文件）。
产出：
1. **LLD 低阶设计文档**（Excel 格式；结构与产出方式在运行时按用户意图与模板决策生成，不同场景必然不同，见 Step 1/3）
2. **存量→动网转换 Python 代码**（解析存量配置，计算 delta，渲染命令脚本 + 变更摘要）
3. **质量评判报告**（三层体系，见 Step 5 与 `references/quality-rubric.md`）

Input: scenario + NE type + NE version (+ existing config). Output: LLD (Excel), transform code (existing→target delta→command script), and a three-layer quality evaluation report.

## 硬性纪律（全流程有效 / Hard Rules）

- 命令语法与参数取值必须来自知识库检索结果或用户提供的权威资料，不得凭记忆编造；无法确认时标注"待确认"并列入问题清单。
- LLD 表结构（sheet 与列）与命令语法同等约束：必须来自知识库模板或用户提供的模板文件，不得凭空设计（三级兜底见 Step 1 模板决策）。
- 高危命令（删除/复位/去激活/强制类）必须单独列出，经用户人工确认后才能进入交付物。
- 一切产出未通过 Step 5 三层评判前，一律视为草稿。
- Command syntax and parameter values must come from knowledge-base retrieval or user-supplied authoritative material — never invented from memory.

## 知识库调用配置 (Knowledge Base Config)

本技能依赖核心网知识库 MCP 提供配置模板、参数说明与命令语法。

```
KB_MCP_TOOLS:
```

<!-- 在上行冒号后填入工具名（逗号分隔），例如：KB_MCP_TOOLS: mcp__corenw__search,mcp__corenw__query -->
<!-- 留空时按下面"三段式"调用。修改本文件后即可长期生效。 -->

三段式调用顺序（按序短路）：

1. **已配置**：`KB_MCP_TOOLS` 非空时直接调用所列工具，不另行猜测。
2. **自动发现**：检查当前会话可用的 `mcp__<server>__<tool>` 工具，筛选名称含 knowledge / search / query / kb / 检索 / 知识库，或 server 名含 core / cn / telecom / 3gpp / 网元 者。
   恰好一个 → 直接使用并告知用户；多个 → 列表请用户选择；零个 → 询问用户知识库入口（确无则进入第 3 段）。
3. **联网兜底**：知识库完全不可用时先告知用户，改用 WebSearch/WebFetch 检索 3GPP 官方规范与厂商公开资料；此时所有产出必须标注"来源为公开资料，未经内部知识库校验"，交付前提醒用户人工复核。

检索关键词模板：`{网元类型} {版本} {厂商} 配置 {场景}` + 具体配置域名（如 GUAMI、N2 接口、PDU 会话池）。
每次检索需覆盖：配置模板原文（逐字保留含占位符）、参数说明（名称/取值范围/默认值/版本差异）、命令语法（MML/CLI）、场景约束与已知问题。
检索结果写入工作文件 `kb_notes_<网元类型>.md`（含查询词与命中条目），供 Step 2/4 引用；缺失项列入"知识缺口清单"。

## 工作流程 (Workflow)

整体顺序 Step 0→6。每步结束时把状态写入 LLD JSON（见"状态与恢复"），支持中断续作。
Follow steps 0→6 in order; persist state into the LLD JSON after each step.

### Step 0 需求采集 (Requirement Capture)

询问并记录，以表格形式向用户确认：

1. **场景**：新建局点 / 扩容 / 割接改造 / 切片开通 / 接口对接 / 参数整改 / 其他
2. **网元类型**：5GC（AMF、SMF、UPF、NRF、PCF、UDM、UDR、AUSF、NSSF、NEF、BSF、CHF、SMSF）；EPC（MME、SGW、PGW、HSS、PCRF）；IMS（P-CSCF、I-CSCF、S-CSCF、IMS-HSS、AS）等
3. **网元版本**：版本号 + 厂商。版本差异直接影响命令语法，不可省略。
4. **存量配置**：是否提供样例文件（路径/格式）。新建场景无存量，记录为 greenfield。
5. **期望输出**：LLD / 命令脚本 / 转换代码的组合与格式偏好
6. **约束**：现网数据（IP 段、命名规范）、审批要求等

然后读取 `references/ne-config-map.md` 中该网元的配置域骨架，向用户展示本次涉及的配置域清单并确认裁剪。

### Step 1 知识检索 (Knowledge Retrieval)

按"知识库调用配置"三段式执行；按 Step 0 确认的配置域**逐域检索**并记录：命令模板原文、参数说明、场景约束、已知问题。
**必查项**：`{网元类型} {版本} LLD 模板 / 低阶设计模板 / 设计文档模板`。产出 `kb_notes_<网元类型>.md` 与知识缺口清单。

**模板决策（三级，本步末尾完成）**——LLD 的表结构由此确定，Step 2/3 沿用：

1. **知识库模板**：KB 命中 → 解析其 sheet 与列结构，转为 LLD JSON 的 `template` 节（`source` 填 KB 出处）。
2. **用户模板**：KB 未命中 → 询问用户是否有公司/项目模板文件（xlsx / docx / 文字描述均可）→ 提取表结构（xlsx 用 openpyxl 读 sheet 名与首行表头，docx 读表格；提取结果先向用户展示确认）→ `template` 节（`source` 填文件名）。
3. **内置兜底**：均无 → 使用内置默认骨架（8 sheet 通用格式，不写 template 节），并明确告知用户"这是通用兜底格式，建议将贵司模板入库"。

模板规范与示例见 `references/lld-template-guide.md`（schema v1.1）。

### Step 2 LLD 对话式设计 (Interactive LLD Design)

目标：把 Step 1 得到的模板参数逐项落到具体值。规则：

- **分批提问**：每批 3–5 个问题。分批粒度与顺序按已确定的模板表结构组织——每张表一批、逐列采集取值；兜底模式下按 全局参数 → 接口 → 业务特性 → 数据规划 的默认顺序。不要一次性抛出全部问题。
- **每个问题给出**：参数名与含义、候选取值（来自知识库）、推荐默认值及依据；用户可改可跳过（跳过记"待确认"）。
- **数据规划类问题**（IP 池、VLAN、编号资源）必须对照存量配置检查冲突；新建场景检查自洽性。
- 决策即时写入 LLD JSON；用户回改时更新对应字段并把 `meta.revision` 加 1。
- 涉及高危操作（删除/复位类）时单独确认并记录确认人。
- LLD JSON 的 schema 与填充示例见 `references/lld-template-guide.md`。

### Step 3 LLD Excel 生成 (Generate LLD Excel)

LLD 的结构、内容与产出方式**完全由用户意图（场景/网元/版本）与 Step 1 模板决策结果决定**——本技能不预置渲染代码，Excel 在运行时生成：

1. 把 Step 2 决策整理为 **LLD JSON**（v1.1 `template`+`data`，规范见 `references/lld-template-guide.md`）。它是结构化载体：供校验、状态恢复（中断续作）、Step 4 参数来源使用。
2. 校验：`python scripts/validate_outputs.py --lld lld.json`，FAIL 项修复后重跑。
3. 按意图编写 Excel 生成代码（openpyxl 等，存放于用户工作目录），按 LLD JSON 的模板结构画表；特殊版式、多级表头等按需实现；用户对产出方式有明确要求时遵从用户。
4. 检查产出：表完整、必填项无空、命令清单含依据。

### Step 4 Python 代码生成 (Generate Transform Code)

转换代码**完全在运行时按本次意图生成**——存量配置格式、场景、命令模板、用户偏好每次不同，代码必然不同；本技能**不预置任何具体代码或固定实现**，只规定必须满足的质量要求（决策点与要求详见 `references/codegen-guide.md`）：

- 职责分层：解析存量 → 载入设计参数 → 计算存量→目标 delta → 按知识库命令模板渲染命令 → 输出命令脚本与变更摘要
- 幂等可重跑（参与交付的输出文件不得含时间戳/随机数）
- 命令分组注释、高危命令标注、命令脚本头部带回滚提示区
- 代码存放于用户工作目录，不放本技能目录

可选约定：代码若接受 `--lld/--existing/--outdir` CLI，可启用 validate_outputs.py 的自动执行与幂等评估；不采用时评判环节手动运行两次比对（见 quality-rubric.md）。

### Step 5 质量评判 (Quality Evaluation)

按 `references/quality-rubric.md` 三层体系 **fail-fast** 执行：

- **第 1 层 确定性自动校验**：
  `python scripts/validate_outputs.py --lld lld.json --cmds <命令脚本> --code <转换代码> --existing <存量样例>`
- **第 2 层 执行式评估**：上条命令的 `--code` 模式自动完成（实际运行两次并逐字节比对 + 输出非空断言）；代码未采用可选 CLI 约定时，手动运行两次比对，判定标准不变。
- **第 3 层 LLM 评分卡**：按 rubric 锚定量表逐维度评分，每个判定必须引用具体证据；A/B 迭代用成对比较。

结论规则：第 1–2 层任一 FAIL → 直接返工（不进入打分）；全过且第 3 层总分 ≥4.0 → 可交付；3.0–4.0 → 小改后复评；<3.0 → 返工。高危命令无论评分如何，须用户人工确认后方可交付。按 rubric 模板产出评判报告。

### Step 6 迭代改进 (Iterate)

按评判报告逐项修复：定位问题 → 修改（LLD JSON / 转换代码 / 命令模板）→ 回 Step 5 重评。
A/B 对比：同一份存量配置下新旧版本输出成对比较，交换呈现顺序评两次，结论一致才采纳修改。

## 状态与恢复 (State & Resume)

- 状态载体：LLD JSON。`meta.revision` 每轮修订 +1；可在 `meta.stage` 记录当前步骤编号。
- 恢复：读取 LLD JSON 与 `kb_notes_*.md`，向用户确认"上次进行到 Step N，是否继续"后从该步续作。
- 工作目录典型文件：`lld.json`、`kb_notes_<网元类型>.md`、`<网元名>_LLD.xlsx`、`transform_<网元类型>.py`、`commands.*`、`change_summary.md`。

## 参考文件索引 (References)

| 文件 | 何时读取 |
|---|---|
| `references/ne-config-map.md` | Step 0 确认配置域、Step 2 拟定问题清单 |
| `references/lld-template-guide.md` | Step 1 模板决策、Step 2/3 编写 LLD JSON 与生成 Excel |
| `references/codegen-guide.md` | Step 4 生成转换代码时（运行时决策点与质量要求，无预置代码） |
| `references/quality-rubric.md` | Step 5 评判、Step 6 迭代时 |
| `scripts/validate_outputs.py` | Step 3 校验 LLD JSON / Step 5 评判（工具，勿改） |
