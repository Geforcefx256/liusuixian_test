#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_outputs.py — 质量评判第 1/2 层执行器（见 references/quality-rubric.md）

用法:
    python validate_outputs.py --lld lld.json                       # 第 1 层: LLD JSON 校验
    python validate_outputs.py --cmds commands.txt                  # 第 1 层: 命令脚本校验
    python validate_outputs.py --code transform.py \
        --existing existing.cfg --lld lld.json                      # 第 1 层(编译) + 第 2 层(执行/幂等)

转换代码可选 CLI 约定（见 references/codegen-guide.md）:
    transform.py --lld lld.json [--existing 存量文件] --outdir 目录
    采用该约定可启用 --code 模式的自动执行与幂等评估；不采用时评判者手动双跑比对。

LLD 校验支持两种模式:
    v1.0 兜底模式（配置节）与 v1.1 模板模式（template + data）。

退出码: 0 = 无 FAIL（允许 WARN）；1 = 存在 FAIL。
"""
import argparse
import filecmp
import json
import os
import py_compile
import re
import shutil
import subprocess
import sys
import tempfile

# ---------------- LLD JSON 校验（v1.0 / v1.1） ----------------

SCHEMA_10 = "core-network-lld/1.0"
SCHEMA_11 = "core-network-lld/1.1"
REQUIRED_META = ["project", "scenario", "ne_type", "ne_name", "vendor",
                 "version", "author", "date", "revision"]
BODY_SECTIONS = ["global_params", "interfaces", "service_params", "data_plan"]
PLACEHOLDER_RE = re.compile(r"TODO|FIXME|XXX|<[A-Za-z_][^>]*>|\{[A-Za-z_][A-Za-z0-9_]*\}")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _check_meta(lld, problems):
    meta = lld.get("meta")
    if not isinstance(meta, dict):
        problems.append("缺少 meta 对象")
        return
    for key in REQUIRED_META:
        val = meta.get(key)
        if val is None or (isinstance(val, str) and not val.strip()):
            problems.append(f"meta.{key} 缺失或为空")
    if meta.get("date") and not DATE_RE.match(str(meta["date"])):
        problems.append("meta.date 须为 YYYY-MM-DD")
    try:
        int(meta.get("revision"))
    except (TypeError, ValueError):
        problems.append("meta.revision 须为整数")


def _check_template(lld, problems):
    """v1.1 模板模式校验：template/data 结构、引用完整性、行列一致。"""
    tpl, data = lld.get("template"), lld.get("data")
    if not isinstance(tpl, dict):
        problems.append("template 须为对象")
        return
    if not (isinstance(tpl.get("source"), str) and tpl["source"].strip()):
        problems.append("template.source 缺失或为空（模板出处必须可追溯）")
    sheets = tpl.get("sheets")
    if not isinstance(sheets, list) or not sheets:
        problems.append("template.sheets 须为非空数组")
        return
    if not isinstance(data, dict):
        problems.append("使用 template 时缺少 data 节")
        data = {}
    for i, sh in enumerate(sheets):
        if not isinstance(sh, dict):
            problems.append(f"template.sheets[{i}] 须为对象")
            continue
        title = sh.get("title")
        cols = sh.get("columns")
        ref = sh.get("data_ref")
        if not (isinstance(title, str) and title.strip()):
            title = f"sheets[{i}]"
            problems.append(f"template.sheets[{i}].title 缺失或为空")
        if not (isinstance(cols, list) and cols
                and all(isinstance(c, str) and c.strip() for c in cols)):
            problems.append(f"template.sheets[{i}].columns 须为非空字符串数组")
            cols = cols if isinstance(cols, list) else []
        if not (isinstance(ref, str) and ref.strip()):
            problems.append(f"template.sheets[{i}].data_ref 缺失或为空")
            continue
        rows = data.get(ref)
        if rows is None:
            problems.append(f"data 缺少被引用的键 {ref!r}（表「{title}」）")
            continue
        if not isinstance(rows, list):
            problems.append(f"data.{ref} 须为数组")
            continue
        for r, row in enumerate(rows):
            if not isinstance(row, list):
                problems.append(f"data.{ref}[{r}] 须为数组")
            elif cols and len(row) != len(cols):
                problems.append(
                    f"data.{ref}[{r}] 行长度 {len(row)} ≠ 表「{title}」列数 {len(cols)}")
    if not any(isinstance(v, list) and v for v in data.values()):
        problems.append("全部数据表为空（template 模式要求至少一张表有数据）")


def check_lld(lld):
    """返回 (硬错误列表, 占位符告警列表)。"""
    problems, placeholders = [], []

    if not isinstance(lld, dict):
        return ["LLD 根节点须为对象"], []

    schema = lld.get("schema")
    if schema not in (SCHEMA_10, SCHEMA_11):
        problems.append(
            f'schema 须为 "{SCHEMA_10}" 或 "{SCHEMA_11}"，当前为 {schema!r}')

    _check_meta(lld, problems)

    if schema == SCHEMA_11 and "template" in lld:
        _check_template(lld, problems)
    else:
        for sec in BODY_SECTIONS:
            if sec in lld and not isinstance(lld[sec], list):
                problems.append(f"{sec} 须为数组")
        if all(not lld.get(sec) for sec in BODY_SECTIONS):
            problems.append(
                "global_params/interfaces/service_params/data_plan 至少一项非空"
                "（或改用 v1.1 template 模式）")

    def walk(node, path):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}")
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, str) and PLACEHOLDER_RE.search(node):
            placeholders.append(f"{path}: {node.strip()[:60]}")

    walk(lld, "$")
    return problems, placeholders


def _orphan_data_keys(lld):
    """data 中未被任何 sheet 引用的键（告警，不算硬错误）。"""
    tpl = lld.get("template") or {}
    sheets = tpl.get("sheets") if isinstance(tpl, dict) else None
    refs = {sh.get("data_ref") for sh in (sheets or []) if isinstance(sh, dict)}
    data = lld.get("data")
    return [k for k in (data if isinstance(data, dict) else {}) if k not in refs]


# ---------------- 命令脚本校验 ----------------

# 高危命令关键词（第 1 层扫描 → WARN，进入人工审核关卡）
RISK_KEYWORDS = [
    "RMV", "DEL", "DELETE", "REMOVE", "RESET", "RST", "DEACT", "DEACTIVATE",
    "FORCE", "CLR", "UNREGISTER", "PURGE",
    "删除", "复位", "去激活", "清除", "强制", "注销", "铲除",
]
# 删除类（用于"先删后建"冲突启发式）
DELETE_RE = re.compile(r"\b(RMV|DEL(ETE)?|REMOVE|RESET|RST|DEACT\w*|PURGE)\b|删除|复位|去激活|清除", re.I)
SET_RE = re.compile(r"\b(SET|ADD|MOD|CREATE|CFG|CONFIG)\b|配置|设置|新增", re.I)
IDENT_RE = re.compile(r"[A-Za-z0-9_.\-]{4,}")
GENERIC_WORDS = {"DELETE", "REMOVE", "RESET", "DEACT", "DEACTIVATE", "PURGE",
                 "RMV", "CLR", "FORCE", "RST",
                 "SET", "ADD", "MOD", "CREATE", "CFG", "CONFIG", "TRUE", "FALSE"}


class Report:
    def __init__(self):
        self.fails = 0
        self.warns = 0

    def fail(self, msg):
        self.fails += 1
        print(f"  [FAIL] {msg}")

    def warn(self, msg):
        self.warns += 1
        print(f"  [WARN] {msg}")

    def ok(self, msg):
        print(f"  [PASS] {msg}")


def validate_lld(path, rep):
    print("== 第 1 层: LLD JSON 校验 ==")
    try:
        with open(path, encoding="utf-8") as f:
            lld = json.load(f)
    except (OSError, ValueError) as e:
        rep.fail(f"无法读取/解析 LLD JSON: {e}")
        return
    problems, placeholders = check_lld(lld)
    for p in problems:
        rep.fail(p)
    for p in placeholders:
        rep.warn(f"疑似占位符未替换 → {p}")
    for k in _orphan_data_keys(lld):
        rep.warn(f"data.{k} 未被任何 sheet 引用（孤儿数据，不会体现在交付物中）")
    if not problems:
        rep.ok(f"schema/meta/模板/数据检查通过（{len(placeholders)} 处占位符告警）")


def _strip_comment(line):
    for marker in ("/*", "//", "! ", "# "):
        idx = line.find(marker)
        if idx > 0:
            line = line[:idx]
    return line.strip()


def validate_cmds(path, rep):
    print("== 第 1 层: 命令脚本校验 ==")
    try:
        with open(path, encoding="utf-8") as f:
            raw_lines = f.read().splitlines()
    except OSError as e:
        rep.fail(f"无法读取命令脚本: {e}")
        return

    cmds = []           # (行号, 命令原文)
    for no, line in enumerate(raw_lines, 1):
        s = _strip_comment(line)
        if not s or s.startswith(("!", "#", "//", "=", "-")):
            continue
        cmds.append((no, s))
    if not cmds:
        rep.fail("命令脚本中没有有效命令")
        return

    # 1) 完全重复命令 → FAIL
    seen = {}
    dups = []
    for no, c in cmds:
        key = re.sub(r"\s+", " ", c)
        if key in seen:
            dups.append(f"行{no} 与 行{seen[key]} 重复: {c[:60]}")
        else:
            seen[key] = no
    if dups:
        for d in dups:
            rep.fail(f"重复命令 → {d}")
    else:
        rep.ok(f"无重复命令（共 {len(cmds)} 条）")

    # 2) 高危命令 → WARN（人工审核关卡清单）
    risk_hits = [f"行{no}: {c[:60]}" for no, c in cmds
                 if any(re.search(rf"\b{kw}\b", c, re.I) if kw.isascii() else kw in c
                        for kw in RISK_KEYWORDS)]
    if risk_hits:
        for r in risk_hits:
            rep.warn(f"高危命令，需人工确认 → {r}")
    else:
        rep.ok("未检出高危命令")

    # 3) 先删后建同对象（冲突对）→ WARN 转人工确认
    conflicts = []
    for i, (no_i, ci) in enumerate(cmds):
        if not DELETE_RE.search(ci):
            continue
        idents = {m for m in IDENT_RE.findall(ci)
                  if m.upper() not in GENERIC_WORDS}
        if not idents:
            continue
        for no_j, cj in cmds[i + 1:]:
            if DELETE_RE.search(cj):
                continue
            if SET_RE.search(cj) and any(ident in cj for ident in idents):
                conflicts.append(f"行{no_i} 删除后 行{no_j} 又配置同对象: {ci[:40]} / {cj[:40]}")
                break
    if conflicts:
        for c in conflicts:
            rep.warn(f"疑似先删后建冲突（转人工确认）→ {c}")
    else:
        rep.ok("未检出先删后建冲突对")


def run_once(code, lld, existing, outdir):
    cmd = [sys.executable, os.path.abspath(code), "--lld", os.path.abspath(lld),
           "--outdir", outdir]
    if existing:
        cmd += ["--existing", os.path.abspath(existing)]
    return subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=120)


def _collect_outputs(outdir):
    """参与交付比对的文件（排除日志）: 返回 {文件名: 绝对路径}"""
    result = {}
    for root, _dirs, files in os.walk(outdir):
        for fn in files:
            if fn.lower().endswith(".log"):
                continue
            result[fn] = os.path.join(root, fn)
    return result


def validate_code(code, lld, existing, rep):
    print("== 第 1 层: 转换代码编译检查 ==")
    try:
        py_compile.compile(code, doraise=True)
        rep.ok("语法编译通过")
    except py_compile.PyCompileError as e:
        rep.fail(f"编译失败: {e}")
        return

    if not lld:
        rep.warn("未提供 --lld，跳过第 2 层执行式评估")
        return

    print("== 第 2 层: 执行式评估（运行两次 + 幂等比对）==")
    tmp = tempfile.mkdtemp(prefix="lld_eval_")
    try:
        run1_dir = os.path.join(tmp, "run1")
        run2_dir = os.path.join(tmp, "run2")
        r1, r2 = run_once(code, lld, existing, run1_dir), run_once(code, lld, existing, run2_dir)

        for tag, r in (("第1次", r1), ("第2次", r2)):
            if r.returncode != 0:
                rep.fail(f"{tag}运行异常退出 code={r.returncode}; stderr 尾部: "
                         f"{(r.stderr or '').strip().splitlines()[-3:]}")
                return
        rep.ok("两次运行均成功退出")

        out1 = _collect_outputs(run1_dir)
        if not out1 or all(os.path.getsize(p) == 0 for p in out1.values()):
            rep.fail("输出为空：未产出任何非空交付文件")
            return
        rep.ok(f"输出非空（{len(out1)} 个交付文件）")

        out2 = _collect_outputs(run2_dir)
        idem_ok = True
        for fn, p1 in sorted(out1.items()):
            p2 = out2.get(fn)
            if p2 is None:
                rep.fail(f"幂等性破坏: 第2次运行缺少文件 {fn}")
                idem_ok = False
            elif not filecmp.cmp(p1, p2, shallow=False):
                rep.fail(f"幂等性破坏: {fn} 两次运行内容不一致")
                idem_ok = False
        for fn in set(out2) - set(out1):
            rep.fail(f"幂等性破坏: 第2次运行多出文件 {fn}")
            idem_ok = False
        if idem_ok:
            rep.ok(f"幂等性通过（{len(out1)} 个文件逐字节一致）")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser(description="质量评判第 1/2 层执行器")
    ap.add_argument("--lld", help="LLD JSON 路径")
    ap.add_argument("--cmds", help="动网命令脚本路径")
    ap.add_argument("--code", help="转换代码路径")
    ap.add_argument("--existing", help="存量配置样例路径")
    args = ap.parse_args()

    if not (args.lld or args.cmds or args.code):
        ap.error("至少提供 --lld / --cmds / --code 之一")

    rep = Report()
    if args.lld:
        validate_lld(args.lld, rep)
    if args.cmds:
        validate_cmds(args.cmds, rep)
    if args.code:
        validate_code(args.code, args.lld, args.existing, rep)

    print(f"\n汇总: FAIL={rep.fails}  WARN={rep.warns}")
    print("结论: " + ("返工（存在 FAIL）" if rep.fails else
                     "第 1–2 层通过（WARN 项转人工确认）"))
    sys.exit(1 if rep.fails else 0)


if __name__ == "__main__":
    main()
