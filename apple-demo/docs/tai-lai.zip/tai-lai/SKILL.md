---
id: tai-lai
name: tai-lai
description: 根据用户提供的命令或命令样例，以及TAI/LAI迁移的规划数据表，生成SMF网元的TAI/LAI迁移脚本。触发关键词：TAC迁移、LAC迁移、业务割接、Service Cutover、TAC Migration、LAC Migration、TAI迁移、LAI迁移、TAI Migration、LAI Migration
---

# 约束条件
 1. 没有在当前文档中出现的参数不要自己想象
 2. 不要生成本Skill中未提到的其他不相关命令
# TAC/LAC的变更数据规划表

- 规划数据示例：

    | 网络类型 | 服务区类型 | 起始服务区 | 终止服务区 | 原UPF服务区 | 新UPF服务区 |
    | --------|------|------|---------|---------|------|
    | 2/3G | LAI | 6040204E4 |6040204E4 |zonetan2_lai|zonetec1_lai|
    | 4G | TAI | 6040204E4 |6040204E4 |zonetan2_lai||
    | 5G | TAI | 6040204E4 |6040204E4 ||zonetec1_lai|

# 方案实现步骤

## 方案准备阶段

1. 根据规划数据示例中的规划数据格式生成csv格式文件，提示用户在工作区output目录下载，用户填写规划数据后上传到工作区。
2. 主动询问用户是否需要参考SMF网元现网配置，如果需要，提示用户上传现网配置到工作区。

## 规划数据处理阶段

1. 根据用户提供的规划数据表，将规划数据按照如下原则分类：
    - 当“原UPF服务区”为空且“新UPF服务区”不为空时，将对应行标识为“新增”，填写到“变更类型”列；
    - 当“原UPF服务区”不为空且“新UPF服务区”为空时，将对应行标识为“删除”，填写到“变更类型”列；
    - 当“原UPF服务区”和“新UPF服务区”均不为空且取值不相等时，将对应行标识为“修改”，填写到“变更类型”列；
    - 当“原UPF服务区”和“新UPF服务区”均为空或者取值相等时，将对应行标识为“无效”，填写到“变更类型”列
    
    处理后的规划数据示例如下表： 

    | 网络类型 | 服务区类型 | 起始服务区 | 终止服务区 | 原UPF服务区 | 新UPF服务区 | 变更类型 |
    | --------|------|------|---------|---------|------|------|
    | 2/3G | LAI | 6040204E4 |6040204E4 |zonetan2_lai|zonetec1_lai|修改|
    | 4G | TAI | 6040204E4 |6040204E4 |zonetan2_lai||删除|
    | 5G | TAI | 6040204E4 |6040204E4 ||zonetec1_lai|新增|
    | 5G | TAI | 6040204E4 |6040204E4 |||无效|    
## MML脚本生成阶段

1. 找到规划数据处理阶段“变更类型”为“新增”或“修改”的“新UPF服务区”和对应的“网络类型”取值，在用户提供的现网配置中查找ADD UPAREA命令，按照如下规则处理：
    - 当“新UPF服务区”的取值在现网配置中找不到对应的ADD UPAREA命令，则需要用ADD UPAREA命令先添加该UPAREA。该命令中参数AREANAME跟“新UPF服务区”的取值保持一致，参数AREATYPE根据“新UPF服务区”对应的“网络类型”取对应的枚举值，参考下面的参数AREATYPE和“网络类型”的对应关系表

    - 当“新UPF服务区”的取值在现网配置中能找到对应的ADD UPAREA命令，但是参数AREATYPE和“网络类型”不满足下表中的对应关系，则需要用ADD UPAREA命令先添加该UPAREA。该命令中参数AREANAME跟“新UPF服务区”的取值保持一致，参数AREATYPE根据“新UPF服务区”对应的“网络类型”取对应的枚举值，参考下面的参数AREATYPE和“网络类型”的对应关系表

    - 当“新UPF服务区”的取值在现网配置中能找到对应的ADD UPAREA命令，且参数AREATYPE和“网络类型”满足下表中的对应关系，则无需额外处理。
    - 参数AREATYPE和“网络类型”的对应关系如下：

        | AREATYPE | 网络类型 |
        | --- |---|
        | S1TAI | 4G |
        | N2TAI | 5G |
        | LAI | 2/3G |    

2. 根据规划数据处理阶段中标识的“变更类型”，按照用户填写的规划数据和下表中的规则生成MML脚本：
    | 变更类型 | 网络类型 | MML脚本 | 参数和规划数据映射关系（参数：规划数据） | 
    | --------|------|------|---------|
    | 新增 | 2/3G | ADD UPAREABINDLAI:AREANAME="zonetec1_lai", BEGINLAI="6040204E4", ENDLAI="6040204E4"; |AREANAME：新UPF服务区  BEGINLAI：起始服务区  ENDLAI：终止服务区 |
    | 新增 | 4G | ADD UPAREABINDS1TAI:AREANAME="zonetec1_tai", S1BEGINTAI="6040204E4", S1ENDTAI="6040204E4"; |AREANAME：新UPF服务区  S1BEGINTAI：起始服务区  S1ENDTAI：终止服务区 |  
    | 新增 | 5G | ADD UPAREABINDN2TAI: AREANAME="zonetec1_tai", N2BEGINTAI="6040204E4", N2ENDTAI="6040204E4"; |AREANAME：新UPF服务区  N2BEGINTAI：起始服务区  N2ENDTAI：终止服务区 |
    | 删除 | 2/3G | RMV UPAREABINDLAI:AREANAME="zonetan2_lai", BEGINLAI="6040204E4"; |AREANAME：原UPF服务区  BEGINLAI：起始服务区 |
    | 删除 | 4G | RMV UPAREABINDS1TAI:AREANAME="zonetec1_tai", S1BEGINTAI="6040204E4", S1ENDTAI="6040204E4"; |AREANAME：原UPF服务区  S1BEGINTAI：起始服务区  S1ENDTAI：终止服务区 |  
    | 删除 | 5G | RMV UPAREABINDN2TAI: AREANAME="zonetec1_tai", N2BEGINTAI="6040204E4", N2ENDTAI="6040204E4"; |AREANAME：原UPF服务区  N2BEGINTAI：起始服务区  N2ENDTAI：终止服务区 |
    | 修改 | 2/3G | RMV UPAREABINDLAI:AREANAME="zonetan2_lai", BEGINLAI="6040204E4"; ADD UPAREABINDLAI:AREANAME="zonetec1_lai", BEGINLAI="6040204E4", ENDLAI="6040204E4"; |对于RMV命令，AREANAME：原UPF服务区  BEGINLAI：起始服务区；对于ADD命令，AREANAME：新UPF服务区  S1BEGINTAI：起始服务区  S1ENDTAI：终止服务区 |
    | 修改 | 4G | RMV UPAREABINDS1TAI:AREANAME="zonetec1_tai", S1BEGINTAI="6040204E4", S1ENDTAI="6040204E4"; ADD UPAREABINDS1TAI:AREANAME="zonetec1_tai", S1BEGINTAI="6040204E4", S1ENDTAI="6040204E4"; |对于RMV命令，AREANAME：原UPF服务区  S1BEGINTAI：起始服务区  S1ENDTAI：终止服务区；对于ADD命令，AREANAME：新UPF服务区  S1BEGINTAI：起始服务区  S1ENDTAI：终止服务区|  
    | 修改 | 5G | RMV UPAREABINDN2TAI: AREANAME="zonetec1_tai", N2BEGINTAI="6040204E4", N2ENDTAI="6040204E4"; ADD UPAREABINDN2TAI: AREANAME="zonetec1_tai", N2BEGINTAI="6040204E4", N2ENDTAI="6040204E4";|对于RMV命令，AREANAME：原UPF服务区  N2BEGINTAI：起始服务区  N2ENDTAI：终止服务区；对于ADD命令，AREANAME：新UPF服务区  N2BEGINTAI：起始服务区  N2ENDTAI：终止服务区 |    

3. 在生成的MML脚本中，ADD UPAREA命令需要写到对应的ADD UPAREABINDLAI、ADD UPAREABINDS1TAI、ADD UPAREABINDN2TAI命令之前
4. 要求生成的命令分行展示，每条命令以“;”结尾
5. 现网配置的命令不要出现在生成的配置脚本中

## 最终生成的MML脚本示例

- SMF脚本示例：
    
    RMV UPAREABINDS1TAI:AREANAME="zonetan2_tai", S1BEGINTAI="6040204E4", S1ENDTAI="6040204E4";
    RMV UPAREABINDLAI:AREANAME="zonetan2_lai", BEGINLAI="6040204E4";

    ADD UPAREABINDS1TAI:AREANAME="zonetec1_tai", S1BEGINTAI="6040204E4", S1ENDTAI="6040204E4";
    ADD UPAREABINDLAI:AREANAME="zonetec1_lai", BEGINLAI="6040204E4", ENDLAI="6040204E4";

